﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DynamicDNAPerformanceReview.Controllers
{
    public class AccountController : Controller
    {
        public CRMSEntities3Entities DNA = new CRMSEntities3Entities();
        // GET: Account
        public ActionResult Employees()
        {
            return View(DNA.UserAccounts.ToList());
        }


        //public static string Decrypt(string encryptionKey, string cipherString, bool useHashing)
        //{
        //    byte[] keyArray;
        //    //get the byte code of the string

        //    byte[] toEncryptArray = Convert.FromBase64String(cipherString);

        //    System.Configuration.AppSettingsReader settingsReader =
        //                                        new AppSettingsReader();

        //    if (useHashing)
        //    {
        //        //if hashing was used get the hash code with regards to your key
        //        MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
        //        keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(encryptionKey));
        //        //release any resource held by the MD5CryptoServiceProvider

        //        hashmd5.Clear();
        //    }
        //    else
        //    {
        //        //if hashing was not implemented get the byte code of the key
        //        keyArray = UTF8Encoding.UTF8.GetBytes(encryptionKey);
        //    }

        //    TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
        //    //set the secret key for the tripleDES algorithm
        //    tdes.Key = keyArray;
        //    //mode of operation. there are other 4 modes.
        //    //We choose ECB(Electronic code Book)

        //    tdes.Mode = CipherMode.ECB;
        //    //padding mode(if any extra byte added)
        //    tdes.Padding = PaddingMode.PKCS7;

        //    ICryptoTransform cTransform = tdes.CreateDecryptor();
        //    byte[] resultArray = cTransform.TransformFinalBlock(
        //                         toEncryptArray, 0, toEncryptArray.Length);
        //    //Release resources held by TripleDes Encryptor
        //    tdes.Clear();
        //    //return the Clear decrypted TEXT
        //    return UTF8Encoding.UTF8.GetString(resultArray);
        //}

        ///// <summary>
        ///// Encrypts the specified to encrypt.
        ///// </summary>
        ///// <param name="toEncrypt">To encrypt.</param>
        ///// <param name="useHashing">if set to <c>true</c> [use hashing].</param>
        ///// <returns>
        ///// The encrypted string to be stored in the Database
        ///// </returns>
        //public static string Encrypt(string encryptionKey, string toEncrypt, bool useHashing)
        //{
        //    byte[] keyArray;
        //    byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

        //    System.Configuration.AppSettingsReader settingsReader =
        //                                        new AppSettingsReader();

        //    //If hashing use get hashcode regards to your key
        //    if (useHashing)
        //    {
        //        MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
        //        keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(encryptionKey));
        //        //Always release the resources and flush data
        //        // of the Cryptographic service provide. Best Practice

        //        hashmd5.Clear();
        //    }
        //    else
        //        keyArray = UTF8Encoding.UTF8.GetBytes(encryptionKey);

        //    TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
        //    //set the secret key for the tripleDES algorithm
        //    tdes.Key = keyArray;
        //    //mode of operation. there are other 4 modes.
        //    //We choose ECB(Electronic code Book)
        //    tdes.Mode = CipherMode.ECB;
        //    //padding mode(if any extra byte added)

        //    tdes.Padding = PaddingMode.PKCS7;

        //    ICryptoTransform cTransform = tdes.CreateEncryptor();
        //    //transform the specified region of bytes array to resultArray
        //    byte[] resultArray =
        //      cTransform.TransformFinalBlock(toEncryptArray, 0,
        //      toEncryptArray.Length);
        //    //Release resources held by TripleDes Encryptor
        //    tdes.Clear();
        //    //Return the encrypted data into unreadable string format
        //    return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        //}










        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(UserAccount account)
        { using (DNA)
                {
                    DNA.UserAccounts.Add(account);

                    DNA.SaveChanges();
                }
                ModelState.Clear();
                //var user = User.Identity;
                //ViewBag.EmployeeName = user.Name;
                ViewBag.Message = account.EmployeeName + " " + " " + account.EmployeeSurname + " Succesfully registered.";

            
            return View("Register");
        }

        public ActionResult Login()
        {
            return View();
        }

        //just added this. at first it was HttpPost
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]

        public ActionResult Login(UserAccount user, Management MAN, string returnurl)
        {
           
                using (DNA)
                {
                    string UUsername = user.Username;
                    string Password = user.Password;

                    //ADMIN.
                    string usen = MAN.Username;
                    string pass = MAN.Password;
                    //
                    var loggenIn = DNA.UserAccounts.FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password);
                    //ADMIN///////////////////////////////////////////////////////
                    var admin = DNA.Managements.FirstOrDefault(m => m.Username == MAN.Username && m.Password == MAN.Password);
                   

                    if (admin != null)
                    { //check if user exist
                        Session["ManagementID"] = MAN.ManagementID;
                    Session.Timeout = 30;
                    FormsAuthentication.SetAuthCookie(usen, true);
                        if (Url.IsLocalUrl(returnurl) && returnurl.Length > 1 && returnurl.StartsWith("/")
                            && !returnurl.StartsWith("//") && !returnurl.StartsWith("/\\"))


                        {
                            return Redirect(returnurl);
                        }
                        else
                        {
                            return RedirectToAction("AdminList", "Reviews");

                        }


                    }
                    ////////////////////////////////////////////////////////////////////
                    if (loggenIn != null)


                    { //check if user exist
                        Session["UserId"] = loggenIn.UserID;
                    Session.Timeout = 30;
                    FormsAuthentication.SetAuthCookie(UUsername, true);
                        if (Url.IsLocalUrl(returnurl) && returnurl.Length > 1 && returnurl.StartsWith("/")
                            && !returnurl.StartsWith("//") && !returnurl.StartsWith("/\\"))
                        {
                            return Redirect(returnurl);
                        }

                        else
                        {
                        //ViewBag.Message = user.EmployeeName + " " + user.EmployeeSurname;
                            return RedirectToAction("Home", "Reviews");

                        }


                    }
                    else
                    {
                        
                        ViewBag.Message = " Username or Password is Invalid";
                    }
            }

            // If we got this far, something failed, redisplay form
            return View(user);
        }


        public ActionResult LogOff()
        {

            Session["UserID"] = null;
            FormsAuthentication.SignOut();
            Session.Clear();  // This may not be needed -- but can't hurt
            Session.Abandon();
            return RedirectToAction("Login", "Account");
        }
    }
}