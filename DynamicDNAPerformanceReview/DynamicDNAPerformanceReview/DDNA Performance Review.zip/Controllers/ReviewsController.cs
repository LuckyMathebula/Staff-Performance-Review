﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DynamicDNAPerformanceReview;
using Rotativa;
using System.IO;
using WebMatrix.Data;
using Ionic.Zip;
using System.IO.Compression;
namespace DynamicDNAPerformanceReview.Controllers
{/*[Authorize]*/
    //[HandleError]
    public class ReviewsController : Controller
    {
        private CRMSEntities3Entities db = new CRMSEntities3Entities();

        // GET: Reviews
        [Authorize]
        public ActionResult Index()
        {

            try
            {
                var userid = (int)Session["UserId"];
                var reviewTables = db.ReviewTables
                    .Where(u => u.fkEmployeeId == userid)
                    .Include(r => r.Management).Include(r => r.UserAccount).OrderBy(e=>e.DateOfReview);
                return View(reviewTables.ToList());
            }
            catch (Exception ex)

            {
                //throw ex;

                return View("Index");

            }
        }

        

        public ActionResult blah()
        {
            return View();
        }

       


        public ActionResult Downloadpdf(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            return View(reviewTable);
        }











        // GET: Reviews/Details/5
        [Authorize]
        public ActionResult Details(int? id)
        {
            Session["Reviewid"] = id;
            Session["ManagementID"] = id;
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            return View(reviewTable);
        }







        [Authorize]
        public ActionResult AdminDetails(int? id)
        {
            Session["Reviewid"] = id;
            Session["ManagementID"] = id;
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            return View(reviewTable);
        }










        // GET: Reviews/Create
        [Authorize]
        public ActionResult Create()
        {
          
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname");
            //ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName");
            return View();
        }

        // POST: Reviews/Create
        // To protect from overposting attacks, please enable the specific properties you want reto bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ReviewID,fkManagementID,fkEmployeeId,RoleOnProject,ProjectEngagement,LineManager,DateOfReview,PeriodOfReview,proPeer,ProManagement,proAgreed,ExPeer,ExMan,ExAgreed,JudPeer,JudMan,JudAgreed,IntPeer,IntMan,IntAgreed,JobPeer,JobMan,JobAgreed,PassPeer,PassMan,PassAgreed,TeaPeer,TeaMan,TeaAgreed,GroPeer,GroMan,GroAgreed,OverallAverage,GeneralComments,prComments,ExComments,JuComments,intComments,JobComments,PassComments,TeaComments,GroComments,CareerPlans,ObjectivesNextPeriod,DueDate")] ReviewTable reviewTable)
        {
            if (ModelState.IsValid)
            {
                reviewTable.fkEmployeeId = Convert.ToInt32(Session["UserId"]);
                db.ReviewTables.Add(reviewTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
           
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname", reviewTable.fkManagementID);
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, reviewTable.fkEmployeeId == reviewTable.UserAccount.UserID);

            return View(reviewTable);
        }

        // GET: Reviews/Edit/5
        [Authorize]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname", reviewTable.fkManagementID);
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName", reviewTable.fkEmployeeId);
            return View(reviewTable);
        }

        // POST: Reviews/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ReviewID,fkManagementID,fkEmployeeId,RoleOnProject,ProjectEngagement,LineManager,DateOfReview,PeriodOfReview,proPeer,ProManagement,proAgreed,ExPeer,ExMan,ExAgreed,JudPeer,JudMan,JudAgreed,IntPeer,IntMan,IntAgreed,JobPeer,JobMan,JobAgreed,PassPeer,PassMan,PassAgreed,TeaPeer,TeaMan,TeaAgreed,GroPeer,GroMan,GroAgreed,OverallAverage,GeneralComments,prComments,ExComments,JuComments,intComments,JobComments,PassComments,TeaComments,GroComments,CareerPlans,ObjectivesNextPeriod,DueDate,OverallAVGman,OverallAVGAgreed")] ReviewTable reviewTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(reviewTable).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("AdminList", "Reviews", "AdminList");
            }
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname", reviewTable.fkManagementID);
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName", reviewTable.fkEmployeeId);
            return View(reviewTable);
        }

        // GET: Reviews/Delete/5
        [Authorize]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            return View(reviewTable);
        }

        // POST: Reviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            db.ReviewTables.Remove(reviewTable);
            db.SaveChanges();
            return RedirectToAction("AdminList", "Reviews", "AdminList");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }


        public ActionResult ExportPDF(UserAccount users,   int id)
        {

            
            return new ActionAsPdf(
                           "Downloadpdf",
                           new { id = id }) 
            {


              

            FileName = User.Identity.Name + "Performance Review.pdf" , PageSize= Rotativa.Options.Size.A4, 
                /*SaveOnServerPath = @"~/Content",  */              CustomSwitches =
                    "--footer-center \"" +  DateTime.Now.Date.ToString("MM/dd/yyyy") + "  Page: [page]/[toPage]\"" + " --footer-line --footer-font-size \"9\" --footer-spacing 6 --footer-font-name \"calibri light\""



            };



        }



        //public ActionResult pdf( int id)
        //{


        //    var fileName = "Perf Review.pdf.pdf";
        //    var filePath = Path.Combine(Server.MapPath("/Downloadss"), fileName);

        //    return new ViewAsPdf("Index", new { id = id })
        //    {
        //        FileName = fileName,
        //        PageSize =Rotativa.Options.Size.A4,
        //        SaveOnServerPath = filePath
        //    };
        //}




        [HttpPost]
        public ActionResult ProcessForm(List<string> selectedfiles)
        {
            if (System.IO.File.Exists(Server.MapPath
                              ("~/zipped/Downloadss.zip")))
            {
                System.IO.File.Delete(Server.MapPath
                              ("~/zipped/Downloadss.zip"));
            }
            ZipArchive zip = System.IO.Compression.ZipFile.Open(Server.MapPath
                     ("~/zipped/Downloadss.zip"), ZipArchiveMode.Create);
            foreach (string file in selectedfiles)
            {
                zip.CreateEntryFromFile(Server.MapPath
                     ("~/Downloadss/" + file), file);
            }
            zip.Dispose();
            return File(Server.MapPath("~/zipped/Downloadss.zip"),
                      "application/zip", "Downloadss.zip");
        }

        [Authorize]
        public ActionResult Download()
        {

            //var dir = new System.IO.DirectoryInfo(Server.MapPath("~/WeeklyLogbooks/"));
            //System.IO.FileInfo[] fileNames = dir.GetFiles("*.*"); List<string> items = new List<string>();
            //foreach (var file in fileNames)
            //{
            //    items.Add(file.Name);
            //}
            //return View(items);


            string[] files = Directory.GetFiles(
                 Server.MapPath("~/Downloadss"));
            List<string> downloads = new List<string>();
            foreach (string file in files)
            {
                downloads.Add(Path.GetFileName(file));
            }
            return View(downloads);
        }

        [Authorize]

        public ActionResult Home()
        {
            return View();
        }


        public ActionResult Modal()
        {
            return View();
        }

        [Authorize]
        [AllowAnonymous]
        [Authorize]
        public ActionResult AdminList()
        {

            if (Session["ManagementID"] == null)
            {
                return Redirect("~/Account/Login");
            }
         
            var manID = (int)Session["ManagementID"];
          
            var reviewTables = db.ReviewTables.Where(u => u.fkManagementID == 1).Include(r => r.Management).Include(r => r.UserAccount).OrderBy(a=>a.DateOfReview);
            return View(reviewTables.ToList());
        }


        public ActionResult Growth()
        {
            return View();
        }



        public ActionResult Chart()
        {
            ViewBag.UserId = Session["UserId"];
            //ViewBag.ManId = Session["ManagementID"];
            return View();
        }




    }
}
