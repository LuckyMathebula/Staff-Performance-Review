﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DynamicDNAPerformanceReview;
using WebMatrix.Data;

namespace DynamicDNAPerformanceReview.Controllers
{
    [Authorize]

 
    public class reboundController : Controller
    {
        private CRMSEntities3Entities db = new CRMSEntities3Entities();

        // GET: rebound
        public ActionResult Index()
        {
            var reviewTables = db.ReviewTables.Include(r => r.Management).Include(r => r.UserAccount);
            return View(reviewTables.ToList());
        }

        // GET: rebound/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            return View(reviewTable);
        }

        // GET: rebound/Create
        public ActionResult Create()
        {
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname");
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName");
            return View();
        }

        // POST: rebound/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ReviewID,fkManagementID,fkEmployeeId,RoleOnProject,ProjectEngagement,LineManager,DateOfReview,PeriodOfReview,proPeer,ProManagement,proAgreed,ExPeer,ExMan,ExAgreed,JudPeer,JudMan,JudAgreed,IntPeer,IntMan,IntAgreed,JobPeer,JobMan,JobAgreed,PassPeer,PassMan,PassAgreed,TeaPeer,TeaMan,TeaAgreed,GroPeer,GroMan,GroAgreed,OverallAverage,GeneralComments,prComments,ExComments,JuComments,intComments,JobComments,PassComments,TeaComments,GroComments,CareerPlans,ObjectivesNextPeriod,DueDate")] ReviewTable reviewTable)
        {
            if (ModelState.IsValid)
            {
                db.ReviewTables.Add(reviewTable);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname", reviewTable.fkManagementID);
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName", reviewTable.fkEmployeeId);
            return View(reviewTable);
        }

        // GET: rebound/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname", reviewTable.fkManagementID);
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName", reviewTable.fkEmployeeId);
            return View(reviewTable);
        }

        // POST: rebound/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ReviewID,fkManagementID,fkEmployeeId,RoleOnProject,ProjectEngagement,LineManager,DateOfReview,PeriodOfReview,proPeer,ProManagement,proAgreed,ExPeer,ExMan,ExAgreed,JudPeer,JudMan,JudAgreed,IntPeer,IntMan,IntAgreed,JobPeer,JobMan,JobAgreed,PassPeer,PassMan,PassAgreed,TeaPeer,TeaMan,TeaAgreed,GroPeer,GroMan,GroAgreed,OverallAverage,GeneralComments,prComments,ExComments,JuComments,intComments,JobComments,PassComments,TeaComments,GroComments,CareerPlans,ObjectivesNextPeriod,DueDate")] ReviewTable reviewTable)
        {
            if (ModelState.IsValid)
            {
                db.Entry(reviewTable).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.fkManagementID = new SelectList(db.Managements, "ManagementID", "Lastname", reviewTable.fkManagementID);
            ViewBag.fkEmployeeId = new SelectList(db.UserAccounts, "UserID", "EmployeeName", reviewTable.fkEmployeeId);
            return View(reviewTable);
        }

        // GET: rebound/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            if (reviewTable == null)
            {
                return HttpNotFound();
            }
            return View(reviewTable);
        }

        // POST: rebound/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ReviewTable reviewTable = db.ReviewTables.Find(id);
            db.ReviewTables.Remove(reviewTable);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        public ActionResult Hello()
        {
            return View();
        }
    }
}
